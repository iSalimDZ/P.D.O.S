NOTE : This is Not An Official Python Project, And You
Have The Right To Modify it And Repost it Only if You 
Mention Me @SalimDZ in Credits.

What is P.D.O.S ? :
A Fun Little Project Made By @SalimDZ, it Was Made For 
The Porpos of Mushing Multiple Tasks and Programs 
Into One Giant Pile Of Sh- a Programs :) , Replacting The
Old OG MC-DOS From Microsoft From The Early 
Generations Of Computers. 

What is New in 0.1.5_prototype3 ? :
• Bug Fixes 
• Calculator Improvements 
• Add a Traingle Hypotenuse Calculator To The 
Calculator 
• Improved Shutting Down Process 
• Add a New App : About 
• The Program Will No Longer Terminat Itself After 
Finishing a Task .

06/02/2025.